from flask import Blueprint, render_template, request,session, url_for,redirect
from flask_login import current_user
from website.models import User, Post
from website.drug.forms import DrugSearchForm
from website import db
from sqlalchemy import func
from website import tabl

from pymongo import MongoClient  
import numpy as np

drug = Blueprint('drug', __name__)

# @drug.route('/drugs',methods=['POST','GET'])
# def drugs():

#     form = DrugSearchForm()
#     dic={}
#     if form.validate_on_submit():
#         print(form.search.data,form.searchby.data)
#         if form.searchby.data==1:
#             #drug_name = form.search.data
#             dic= tabl.find_one({'drug':form.search.data})

#         elif form.searchby.data==2:
           
#             for i in tabl.distinct('conditions'):
#                 if form.search.data in i:
#                      dic= tabl.find_one({'conditions':i})
#         else:
#             dic= tabl.find_one({'brand_list':form.search.data})

#         return redirect("drugs.html", user=current_user,form=form,drugs=tabl.distinct('drug'),drug=dic)

#     return render_template("drugs.html", user=current_user,form=form,drugs=tabl.distinct('drug'),drug=dic)
nested=tabl.distinct('conditions')
cond = [x for sublist in nested for x in sublist]

@drug.route('/drugs',methods=['GET'])
def drugs():
    session['search_name']=''
    form = DrugSearchForm()
    if form.validate_on_submit():

        if form.searchby.data==3:
            brand1 = form.search.data
            print("hello*********************")
            return redirect(url_for('drug.drugSearchResult',user=current_user, form=form,drug=brand1,name='brand_list'))

        if form.searchby.data==2:
            condition = form.search.data
            return redirect(url_for('drug.drugSearchResult',user=current_user, form=form, drug=condition,name='conditions'))

        if form.searchby.data==1:
            drug_name = form.search.data
            return redirect(url_for('drug.drugSearchResult',user=current_user, form=form, drug=drug_name,name='drug'))

    return render_template("drugs.html",user=current_user, form=form, drugs=tabl.distinct('drug'),brand=tabl.distinct('brand_list'),drug={},condition=cond)

@drug.route("/search",methods=["POST","GET"])
def searchresult():
    form = DrugSearchForm()
    if form.validate_on_submit():

        if form.searchby.data==3:
            brand1 = request.form["search"]
            print("hello*********************")
            return redirect(url_for('drugSearchResult',drug=brand1,name='brand_list'))

        if form.searchby.data==2:
            condition = request.form["search"]
            return redirect(url_for('drugSearchResult',drug=condition,name='conditions'))

        if form.searchby.data==1:
            drug_name = request.form["search"]
            return redirect(url_for('drugSearchResult',drug=drug_name,name='drug'))


@drug.route("/<drug>/<name>",methods=["GET","POST"])
def drugSearchResult(drug,name):
    drug=drug
    name=name
    arr=[]
    if(name=="conditions"):
        for i in tabl.distinct('conditions'):
            if drug in i:
                dic = tabl.find_one({name:i})

    else:
        dic = tabl.find_one({name:drug})
    print(dic)
    return render_template('drug.html',drug = dic)



